package Zadatak1;

public class Televizori extends EProizvodi {
    private double velicinaEkrana; // in inches

    public Televizori(String opis, String sifra, double uvoznaCijena, double velicinaEkrana) {
        super(opis, sifra, uvoznaCijena);
        this.velicinaEkrana = velicinaEkrana;
    }

    public double getVelicinaEkrana() {
        return velicinaEkrana;
    }

    @Override
    public double maloprodajnaCijena() {
        double c = osnovnaMaloprodajnaCijena();
        // TV +10% if ekran > 65 inches
        if (velicinaEkrana > 65.0) {
            return c * 1.10;
        }
        return c;
    }

    @Override
    public String toString() {
        return String.format("[TV] %s | %s | Ekran: %.1f\" | Uvozna: %.2f | Maloprodajna: %.2f",
                opis, sifra, velicinaEkrana, uvoznaCijena, maloprodajnaCijena());
    }
}
