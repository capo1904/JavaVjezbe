package Zadatak1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        List<EProizvodi> proizvodi = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\n--- MENI ---");
            System.out.println("1. Unos uredjaja");
            System.out.println("2. Pregled svih uredjaja sa maloprodajnom cijenom");
            System.out.println("3. Pregled uredjaja odredjenog tipa");
            System.out.println("4. Izlaz");
            System.out.print("Odaberite opciju: ");

            String opc = sc.nextLine().trim();
            switch (opc) {
                case "1":
                    unosUredjaja(sc, proizvodi);
                    break;
                case "2":
                    pregledSvih(proizvodi);
                    break;
                case "3":
                    pregledTipa(sc, proizvodi);
                    break;
                case "4":
                    running = false;
                    break;
                default:
                    System.out.println("Nepoznata opcija, pokusajte ponovo.");
            }
        }

        sc.close();
        System.out.println("Kraj programa.");
    }

    // Changed: derive type from first two characters of sifra (as required by zadatak)
    private static void unosUredjaja(Scanner sc, List<EProizvodi> proizvodi) {
        System.out.print("Unesite sifru uredjaja (prva dva znaka RA/TE/TV): ");
        String sifra = sc.nextLine().trim().toUpperCase();
        if (sifra.length() < 2) {
            System.out.println("Sifra mora imati bar 2 znaka. Uredjaj nije dodat.");
            return;
        }
        String tip = sifra.substring(0, 2);
        if (!tip.equals("RA") && !tip.equals("TE") && !tip.equals("TV")) {
            System.out.println("Nepoznat tip u sifri. Ocekivani RA/TE/TV. Uredjaj nije dodat.");
            return;
        }

        System.out.print("Opis: ");
        String opis = sc.nextLine().trim();

        double uvozna = readDouble(sc, "Uvozna cijena: ");

        switch (tip) {
            case "RA":
                System.out.print("Procesor: ");
                String proc = sc.nextLine().trim();
                int mem = readInt(sc, "Memorija (GB): ");
                proizvodi.add(new Racunari(opis, sifra, uvozna, proc, mem));
                System.out.println("Racunari dodat.");
                break;
            case "TE":
                System.out.print("Operativni sistem: ");
                String os = sc.nextLine().trim();
                double ekran = readDouble(sc, "Velicina ekrana (incha): ");
                proizvodi.add(new Telefoni(opis, sifra, uvozna, os, ekran));
                System.out.println("Telefon dodat.");
                break;
            case "TV":
                double ekranTv = readDouble(sc, "Velicina ekrana (incha): ");
                proizvodi.add(new Televizori(opis, sifra, uvozna, ekranTv));
                System.out.println("Televizor dodat.");
                break;
            default:
                // unreachable because of prior validation
                System.out.println("Nepoznat tip. Uredjaj nije dodat.");
        }
    }

    private static void pregledSvih(List<EProizvodi> proizvodi) {
        if (proizvodi.isEmpty()) {
            System.out.println("Nema unesenih uredjaja.");
            return;
        }
        System.out.println("\nSvi proizvodi:");
        for (EProizvodi p : proizvodi) {
            System.out.println(p);
        }
    }

    private static void pregledTipa(Scanner sc, List<EProizvodi> proizvodi) {
        System.out.print("Unesite tip za pregled (RA/TE/TV): ");
        String tip = sc.nextLine().trim().toUpperCase();
        if (tip.length() > 2) tip = tip.substring(0, 2);
        List<EProizvodi> filtrirani = Prodavnica.filterByType(proizvodi, tip);
        if (filtrirani.isEmpty()) {
            System.out.println("Nema uredjaja tog tipa.");
            return;
        }
        System.out.println("\nProizvodi tipa " + tip + ":");
        for (EProizvodi p : filtrirani) {
            System.out.println(p);
        }
    }

    private static double readDouble(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = sc.nextLine().trim();
            try {
                return Double.parseDouble(line);
            } catch (NumberFormatException e) {
                System.out.println("Neispravan broj, pokusajte ponovo.");
            }
        }
    }

    private static int readInt(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = sc.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Neispravan broj, pokusajte ponovo.");
            }
        }
    }
}