/**
 * 
 */
/**
 * 
 */
module Zadatak {
}